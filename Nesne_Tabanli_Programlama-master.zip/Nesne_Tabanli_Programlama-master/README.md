# Nesne_Tabanl-_Programlama
Bişeyler
